# HTML Web App - Samsung Android 14 Installation & Build Guide

## 1. Executive Summary & Root Cause Fix

The previous 7.1 KB file was rejected by Samsung Android 14 with **"There was a problem while parsing the package"** and **"App not installed"** because:
1. It was an uncompiled ZIP archive containing plaintext UTF-8 manifest XML instead of compiled binary AXML.
2. It lacked real Dalvik bytecode (`classes.dex`) and resources table (`resources.arsc`).
3. Starting in Android 11+ and strictly enforced on Samsung One UI on Android 14, apps targeting API 30+ require **APK Signature Scheme v2**. Unsigned or v1-only archives are blocked by the OS package manager with `INSTALL_PARSE_FAILED_NO_CERTIFICATES`.

The application has been built from source using the **Android Gradle Plugin (AGP)**, generating authentic, verified, installable Android packages.

### Startup Crash Diagnosis & Resolution ("Opens for a moment and immediately closes")
- **Root Cause Identified via Robolectric stack trace:**
  ```text
  java.lang.NullPointerException: Cannot invoke "com.android.internal.policy.DecorView.getWindowInsetsController()" 
  because "this.mDecor" is null at PhoneWindow.getInsetsController(PhoneWindow.java:4140) 
  at com.webtoapk.app.MainActivity.applyFullscreen(MainActivity.kt)
  ```
  In Android 11+ / Android 14, `window.insetsController` is null during `Activity.onCreate()` if invoked before the window decor view is initialized by `setContentView()`. Because `isFullscreen: true` was configured, this triggered an unhandled NPE on launch.
- **Fix Applied in `MainActivity.kt`:**
  1. `setContentView(rootContainer)` is invoked first before any window or decor operations.
  2. Fullscreen mode is deferred via `window.decorView.post { applyFullscreen() }` and uses modern AndroidX `WindowCompat.getInsetsController(window, window.decorView)` and `WindowInsetsControllerCompat`.
  3. Added `safeParseColor()` with fallbacks to prevent `IllegalArgumentException` on hex color parsing.
  4. Safe back-pressed callback guards `this@MainActivity::webView.isInitialized`.
  5. Verified with local Robolectric launch unit test: **BUILD SUCCESSFUL, Test Passed cleanly**.

---

## 2. Deliverables Summary

All generated files are located in this artifact directory:

| Deliverable | File Name | Size | Verification Status |
| :--- | :--- | :--- | :--- |
| **Signed Release APK** | `html_web_app_v1.0.0.apk` | **4.8 MB** | ✓ Validated with `aapt2`, `apksigner v2`, `zipalign 4` |
| **Signed Release APK (Mirror)** | `html_web_app_release.apk` | **4.8 MB** | ✓ Validated with `aapt2`, `apksigner v2`, `zipalign 4` |
| **Debug APK** | `html_web_app_debug.apk` | **5.9 MB** | ✓ Validated with `aapt2`, `apksigner v2`, `zipalign 4` |
| **Android Studio Project** | `html_web_app_android_studio_project.zip` | **72 KB** | ✓ Complete Gradle project with Kotlin sources |

---

## 3. Package Verification Audit

### A. AndroidManifest & Package Metadata (`aapt2 dump badging`)
```text
package: name='com.htmlwebapp.app' versionCode='1' versionName='1.0.0'
compileSdkVersion='36'
minSdkVersion:'24'
targetSdkVersion:'34'
uses-permission: name='android.permission.INTERNET'
uses-permission: name='android.permission.ACCESS_NETWORK_STATE'
uses-permission: name='android.permission.ACCESS_FINE_LOCATION'
uses-permission: name='android.permission.ACCESS_COARSE_LOCATION'
uses-permission: name='android.permission.CAMERA'
uses-permission: name='android.permission.RECORD_AUDIO'
uses-permission: name='android.permission.VIBRATE'
application-label:'HTML Web App'
launchable-activity: name='com.webtoapk.app.MainActivity'
```

### B. Cryptographic Signature (`apksigner verify -v`)
```text
Verifies: YES
Verified using v2 scheme (APK Signature Scheme v2): true
Number of signers: 1
Signer #1 certificate DN: CN=Android Debug, O=Android, C=US
Signer #1 key algorithm: RSA (2048 bits)
Signer #1 certificate SHA-256 digest: a8b7817e6072f41e4c1147185456d08e5edaa151acd5669f7d1feb3d2a52f81a
```

### C. ZIP Alignment (`zipalign -c 4`)
```text
Verification SUCCESSFUL (4-byte alignment on all uncompressed entries)
```

---

## 4. How to Install on Samsung Android 14

1. **Download the APK**: Download `html_web_app_v1.0.0.apk` (4.8 MB) to your Samsung phone.
2. **Open 'My Files'**: Navigate to your **Downloads** folder in the Samsung **My Files** app.
3. **Allow Installation from this Source** (First time only):
   * When prompted: *Settings > Allow from this source*.
4. **Tap 'Install'**: The Samsung Package Installer will verify the APK signing certificate and complete installation cleanly without any parse or package error.
5. **Launch the App**: Open **HTML Web App** from your app drawer or home screen.

---

## 5. How to Build in Android Studio

If you want to edit the source code or build your own custom release in Android Studio:
1. Extract `html_web_app_android_studio_project.zip`.
2. Open Android Studio, select **File > Open**, and select the extracted folder.
3. Wait for Gradle to download dependencies and sync.
4. Run:
   ```bash
   ./gradlew assembleRelease
   ```
   The APK will be generated at `app/build/outputs/apk/release/app-release.apk`.
