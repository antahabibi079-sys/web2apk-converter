package com.example.data.model

enum class ConsoleLogLevel {
    LOG, INFO, WARN, ERROR
}

data class ConsoleLog(
    val id: String = java.util.UUID.randomUUID().toString(),
    val level: ConsoleLogLevel = ConsoleLogLevel.LOG,
    val message: String,
    val source: String = "",
    val lineNumber: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)
