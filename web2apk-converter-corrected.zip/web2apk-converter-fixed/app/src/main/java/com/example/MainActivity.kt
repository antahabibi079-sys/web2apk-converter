package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.BuildExportScreen
import com.example.ui.screens.ConfigScreen
import com.example.ui.screens.EditorScreen
import com.example.ui.screens.EmulatorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.WebToApkViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: WebToApkViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainApp(viewModel: WebToApkViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val allProjects by viewModel.allProjects.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    // Display messages
    LaunchedEffect(uiState.message) {
        uiState.message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        val modifier = Modifier.padding(innerPadding)

        when (val screen = uiState.currentScreen) {
            is Screen.Home -> {
                HomeScreen(
                    uiState = uiState,
                    projects = allProjects,
                    onImportZip = { uri, name -> viewModel.importZipArchive(uri, name) },
                    onImportHtml = { uri, name -> viewModel.importHtmlFile(uri, name) },
                    onSelectTemplate = { template -> viewModel.createFromTemplate(template) },
                    onCreateFromUrl = { name, url -> viewModel.createFromUrl(name, url) },
                    onSelectProject = { project, targetScreen ->
                        viewModel.selectProject(project, targetScreen)
                    },
                    onDeleteProject = { project -> viewModel.deleteProject(project) }
                )
            }

            is Screen.Config -> {
                val project = uiState.selectedProject
                    ?: allProjects.firstOrNull { it.id == screen.projectId }

                if (project != null) {
                    BackHandler {
                        viewModel.navigateTo(Screen.Home)
                    }
                    ConfigScreen(
                        project = project,
                        onSave = { updated -> viewModel.updateProject(updated) },
                        onLaunchEmulator = { viewModel.navigateTo(Screen.Emulator(project.id)) },
                        onOpenEditor = { viewModel.navigateTo(Screen.Editor(project.id)) },
                        onBuildApk = { viewModel.buildApk(project) },
                        onBack = { viewModel.navigateTo(Screen.Home) }
                    )
                } else {
                    viewModel.navigateTo(Screen.Home)
                }
            }

            is Screen.Emulator -> {
                val project = uiState.selectedProject
                    ?: allProjects.firstOrNull { it.id == screen.projectId }

                if (project != null) {
                    BackHandler {
                        viewModel.navigateTo(Screen.Config(project.id))
                    }
                    EmulatorScreen(
                        project = project,
                        uiState = uiState,
                        onAddConsoleLog = { msg, lvl, src, line ->
                            viewModel.addConsoleLog(msg, lvl, src, line)
                        },
                        onClearConsoleLogs = { viewModel.clearConsoleLogs() },
                        onOpenConfig = { viewModel.navigateTo(Screen.Config(project.id)) },
                        onOpenEditor = { viewModel.navigateTo(Screen.Editor(project.id)) },
                        onBack = { viewModel.navigateTo(Screen.Config(project.id)) }
                    )
                } else {
                    viewModel.navigateTo(Screen.Home)
                }
            }

            is Screen.Editor -> {
                val project = uiState.selectedProject
                    ?: allProjects.firstOrNull { it.id == screen.projectId }

                if (project != null) {
                    BackHandler {
                        viewModel.navigateTo(Screen.Config(project.id))
                    }
                    EditorScreen(
                        project = project,
                        uiState = uiState,
                        onSelectFile = { file -> viewModel.selectActiveFile(file) },
                        onSaveFile = { content -> viewModel.saveActiveFileContent(content) },
                        onRunInEmulator = { viewModel.navigateTo(Screen.Emulator(project.id)) },
                        onBack = { viewModel.navigateTo(Screen.Config(project.id)) }
                    )
                } else {
                    viewModel.navigateTo(Screen.Home)
                }
            }

            is Screen.BuildExport -> {
                val project = uiState.selectedProject
                    ?: allProjects.firstOrNull { it.id == screen.projectId }

                if (project != null) {
                    BackHandler {
                        viewModel.navigateTo(Screen.Config(project.id))
                    }
                    BuildExportScreen(
                        project = project,
                        uiState = uiState,
                        projectGenerator = viewModel.projectGenerator,
                        onBuildApk = { viewModel.buildApk(project) },
                        onBuildProjectZip = { viewModel.buildProjectZip(project) },
                        onTestEmulator = { viewModel.navigateTo(Screen.Emulator(project.id)) },
                        onBack = { viewModel.navigateTo(Screen.Config(project.id)) }
                    )
                } else {
                    viewModel.navigateTo(Screen.Home)
                }
            }
        }
    }
}
