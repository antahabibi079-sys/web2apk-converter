package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Branding - Electric Blue & Sky Cyan
val BrandPrimary = Color(0xFF0284C7)
val BrandPrimaryLight = Color(0xFF38BDF8)
val BrandPrimaryDark = Color(0xFF0369A1)

// Accent Colors
val AccentGreen = Color(0xFF10B981)
val AccentGreenLight = Color(0xFF34D399)
val AccentAmber = Color(0xFFF59E0B)
val AccentPurple = Color(0xFF8B5CF6)
val AccentRose = Color(0xFFF43F5E)

// Dark Theme Surfaces (Deep Slate)
val SlateBackground = Color(0xFF0B0F19)
val SlateSurface = Color(0xFF111827)
val SlateSurfaceVariant = Color(0xFF1F2937)
val SlateCardBorder = Color(0xFF374151)
val SlateTextPrimary = Color(0xFFF9FAFB)
val SlateTextSecondary = Color(0xFF9CA3AF)
val SlateTextTertiary = Color(0xFF6B7280)

// Light Theme Surfaces (Clean Crisp Slate)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightCardBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightTextTertiary = Color(0xFF94A3B8)

// Code Syntax Colors
val CodeBg = Color(0xFF0D1117)
val CodeTag = Color(0xFF7EE787)
val CodeAttr = Color(0xFF79C0FF)
val CodeString = Color(0xFFA5D6FF)
val CodeComment = Color(0xFF8B949E)
