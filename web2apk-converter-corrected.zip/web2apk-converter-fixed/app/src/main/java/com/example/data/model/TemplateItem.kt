package com.example.data.model

data class TemplateItem(
    val id: String,
    val name: String,
    val description: String,
    val category: String, // "Games", "Utility", "Portfolio", "Productivity"
    val iconEmoji: String,
    val themeColorHex: String,
    val defaultOrientation: String,
    val isFullscreen: Boolean,
    val htmlContent: String,
    val cssContent: String = "",
    val jsContent: String = ""
)

object BuiltInTemplates {
    val list = listOf(
        TemplateItem(
            id = "calc_app",
            name = "Glassmorphism Calculator",
            description = "Modern scientific calculator web app with haptic sound feedback, history memory, and glowing buttons.",
            category = "Utility",
            iconEmoji = "🧮",
            themeColorHex = "#0284C7",
            defaultOrientation = "PORTRAIT",
            isFullscreen = false,
            htmlContent = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>Calculator Pro</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; }
    body { background: radial-gradient(circle at 50% 20%, #1E293B, #0F172A 80%); color:#F8FAFC; height:100vh; display:flex; flex-direction:column; justify-content:flex-end; padding:16px; overflow:hidden; }
    #history { font-size:16px; color:#94A3B8; text-align:right; min-height:24px; margin-bottom:4px; overflow-x:auto; }
    #display { font-size:46px; font-weight:700; text-align:right; margin-bottom:20px; word-break:break-all; min-height:55px; }
    .grid { display:grid; grid-template-columns:repeat(4, 1fr); gap:12px; margin-bottom:12px; }
    button { background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.1); color:#F8FAFC; font-size:22px; font-weight:600; padding:18px 0; border-radius:18px; cursor:pointer; transition:all 0.1s ease; outline:none; }
    button:active { transform:scale(0.95); background:rgba(255,255,255,0.18); }
    button.op { background:rgba(2,132,199,0.25); color:#38BDF8; border-color:rgba(2,132,199,0.4); }
    button.eq { background:#0284C7; color:#FFFFFF; grid-column:span 2; border:none; box-shadow:0 4px 14px rgba(2,132,199,0.5); }
    button.clear { color:#F43F5E; }
  </style>
</head>
<body>
  <div id="history"></div>
  <div id="display">0</div>
  <div class="grid">
    <button class="clear" onclick="clearAll()">C</button>
    <button class="op" onclick="press('(')">(</button>
    <button class="op" onclick="press(')')">)</button>
    <button class="op" onclick="press('/')">÷</button>

    <button onclick="press('7')">7</button>
    <button onclick="press('8')">8</button>
    <button onclick="press('9')">9</button>
    <button class="op" onclick="press('*')">×</button>

    <button onclick="press('4')">4</button>
    <button onclick="press('5')">5</button>
    <button onclick="press('6')">6</button>
    <button class="op" onclick="press('-')">-</button>

    <button onclick="press('1')">1</button>
    <button onclick="press('2')">2</button>
    <button onclick="press('3')">3</button>
    <button class="op" onclick="press('+')">+</button>

    <button onclick="press('0')">0</button>
    <button onclick="press('.')">.</button>
    <button class="eq" onclick="calc()">=</button>
  </div>
  <script>
    let expr = '';
    const disp = document.getElementById('display');
    const hist = document.getElementById('history');

    function press(v) {
      if (expr === '0' && v !== '.') expr = '';
      expr += v;
      disp.innerText = expr || '0';
    }
    function clearAll() {
      expr = '';
      disp.innerText = '0';
      hist.innerText = '';
    }
    function calc() {
      try {
        let clean = expr.replace(/×/g, '*').replace(/÷/g, '/');
        let res = Function('"use strict";return (' + clean + ')')();
        hist.innerText = expr + ' =';
        expr = String(res);
        disp.innerText = expr;
      } catch(e) {
        disp.innerText = 'Error';
        expr = '';
      }
    }
  </script>
</body>
</html>
            """.trimIndent()
        ),
        TemplateItem(
            id = "portfolio_app",
            name = "Creator Portfolio PWA",
            description = "High-performance dark theme personal mobile portfolio with project cards, interactive skills, and contact buttons.",
            category = "Portfolio",
            iconEmoji = "💼",
            themeColorHex = "#8B5CF6",
            defaultOrientation = "PORTRAIT",
            isFullscreen = false,
            htmlContent = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>Alex Carter | Mobile Developer</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; font-family:-apple-system,BlinkMacSystemFont,sans-serif; }
    body { background:#0F172A; color:#E2E8F0; padding:24px 18px 40px; line-height:1.6; }
    .hero { text-align:center; padding:24px 0; }
    .avatar { width:88px; height:88px; border-radius:50%; background:linear-gradient(135deg, #8B5CF6, #38BDF8); display:flex; align-items:center; justify-content:center; font-size:36px; margin:0 auto 16px; box-shadow:0 8px 24px rgba(139,92,246,0.3); }
    h1 { font-size:24px; font-weight:800; color:#FFFFFF; margin-bottom:4px; }
    .subtitle { color:#38BDF8; font-weight:600; font-size:14px; margin-bottom:12px; }
    .bio { font-size:14px; color:#94A3B8; max-width:320px; margin:0 auto; }
    .section-title { font-size:18px; font-weight:700; margin:28px 0 14px; color:#F8FAFC; border-left:4px solid #8B5CF6; padding-left:10px; }
    .card { background:#1E293B; border-radius:16px; padding:16px; margin-bottom:14px; border:1px solid #334155; }
    .card h3 { font-size:16px; color:#FFFFFF; margin-bottom:6px; }
    .card p { font-size:13px; color:#94A3B8; margin-bottom:10px; }
    .badge { display:inline-block; padding:3px 8px; border-radius:6px; font-size:11px; font-weight:700; background:rgba(139,92,246,0.2); color:#C4B5FD; margin-right:4px; }
    .btn { display:block; width:100%; text-align:center; padding:14px; background:#8B5CF6; color:#FFF; text-decoration:none; border-radius:14px; font-weight:700; margin-top:20px; box-shadow:0 4px 14px rgba(139,92,246,0.4); }
  </style>
</head>
<body>
  <div class="hero">
    <div class="avatar">👨‍💻</div>
    <h1>Alex Carter</h1>
    <div class="subtitle">Full-Stack & Mobile Engineer</div>
    <div class="bio">Building high-performance Android web apps, interactive 3D web experiences, and seamless mobile tools.</div>
  </div>

  <div class="section-title">Featured Projects</div>
  <div class="card">
    <h3>⚡ HyperTrack Fleet</h3>
    <p>Real-time vehicle telemetry app built with WebSockets, offline SQLite, and custom charts.</p>
    <span class="badge">Kotlin</span>
    <span class="badge">Vue.js</span>
    <span class="badge">Leaflet</span>
  </div>

  <div class="card">
    <h3>🎨 PixelCraft Studio</h3>
    <p>In-browser pixel art editor with layer support, GIF animation export, and cloud synchronization.</p>
    <span class="badge">TypeScript</span>
    <span class="badge">WebGL</span>
    <span class="badge">PWA</span>
  </div>

  <div class="section-title">Core Skills</div>
  <div class="card">
    <p><strong>Mobile:</strong> Android (Compose, Kotlin), PWAs, WebView Bridges</p>
    <p><strong>Frontend:</strong> JavaScript (ESNext), React, Tailwind, Canvas API</p>
    <p><strong>Backend:</strong> Node.js, REST, PostgreSQL, Docker</p>
  </div>

  <a href="mailto:alex@example.com" class="btn" onclick="alert('Contact alex@example.com'); return false;">Get in Touch</a>
</body>
</html>
            """.trimIndent()
        ),
        TemplateItem(
            id = "markdown_app",
            name = "Markdown Live Notes",
            description = "Offline-first markdown notepad with split live preview, formatting toolbar, and instant persistence.",
            category = "Productivity",
            iconEmoji = "📝",
            themeColorHex = "#10B981",
            defaultOrientation = "SENSOR",
            isFullscreen = false,
            htmlContent = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>Markdown Notes</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; font-family:-apple-system,BlinkMacSystemFont,sans-serif; }
    body { background:#0F172A; color:#E2E8F0; height:100vh; display:flex; flex-direction:column; overflow:hidden; }
    header { background:#1E293B; padding:12px 16px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #334155; }
    header h2 { font-size:16px; font-weight:700; color:#34D399; }
    .status { font-size:12px; color:#94A3B8; }
    .tabs { display:flex; background:#0B0F19; border-bottom:1px solid #334155; }
    .tab { flex:1; text-align:center; padding:10px 0; font-size:13px; font-weight:600; color:#94A3B8; cursor:pointer; }
    .tab.active { color:#34D399; border-bottom:2px solid #34D399; }
    .content-area { flex:1; position:relative; overflow:hidden; }
    #editor { width:100%; height:100%; background:#0F172A; color:#E2E8F0; padding:16px; border:none; outline:none; font-family:monospace; font-size:14px; resize:none; line-height:1.5; }
    #preview { display:none; width:100%; height:100%; padding:16px; overflow-y:auto; line-height:1.6; }
    #preview h1 { font-size:22px; color:#34D399; margin-bottom:8px; }
    #preview h2 { font-size:18px; color:#6EE7B7; margin-top:14px; margin-bottom:6px; }
    #preview p { margin-bottom:10px; font-size:14px; color:#CBD5E1; }
    #preview ul { padding-left:20px; margin-bottom:10px; }
  </style>
</head>
<body>
  <header>
    <h2>📝 Markdown Notes</h2>
    <div class="status" id="saveStatus">Auto-saved</div>
  </header>
  <div class="tabs">
    <div class="tab active" id="tabEdit" onclick="switchTab('edit')">Editor</div>
    <div class="tab" id="tabPrev" onclick="switchTab('prev')">Live Preview</div>
  </div>
  <div class="content-area">
    <textarea id="editor" placeholder="Write markdown here..."></textarea>
    <div id="preview"></div>
  </div>
  <script>
    const editor = document.getElementById('editor');
    const preview = document.getElementById('preview');
    const status = document.getElementById('saveStatus');
    const tabEdit = document.getElementById('tabEdit');
    const tabPrev = document.getElementById('tabPrev');

    const saved = localStorage.getItem('md_note') || "# Welcome to Markdown Notes\n\n- Convert any HTML & ZIP to APK\n- Instant live preview\n- Offline local storage\n\n## Fast & Simple\nWrite your thoughts, ideas, and tasks here!";
    editor.value = saved;
    renderPreview();

    editor.addEventListener('input', () => {
      localStorage.setItem('md_note', editor.value);
      status.innerText = 'Saved ' + new Date().toLocaleTimeString();
      renderPreview();
    });

    function switchTab(t) {
      if (t === 'edit') {
        editor.style.display = 'block';
        preview.style.display = 'none';
        tabEdit.classList.add('active');
        tabPrev.classList.remove('active');
      } else {
        renderPreview();
        editor.style.display = 'none';
        preview.style.display = 'block';
        tabPrev.classList.add('active');
        tabEdit.classList.remove('active');
      }
    }

    function renderPreview() {
      let text = editor.value;
      // Simple parser
      let html = text
        .replace(/^# (.*$)/gim, '<h1>$1</h1>')
        .replace(/^## (.*$)/gim, '<h2>$1</h2>')
        .replace(/^### (.*$)/gim, '<h3>$1</h3>')
        .replace(/\*\*(.*)\*\*/gim, '<b>$1</b>')
        .replace(/^\- (.*$)/gim, '<li>$1</li>')
        .replace(/\n$/gim, '<br />');
      preview.innerHTML = html;
    }
  </script>
</body>
</html>
            """.trimIndent()
        )
    )
}
