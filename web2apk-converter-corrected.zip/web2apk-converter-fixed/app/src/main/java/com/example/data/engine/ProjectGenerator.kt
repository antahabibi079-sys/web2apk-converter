package com.example.data.engine

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.model.ProjectEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import org.json.JSONObject

class ProjectGenerator(private val context: Context) {

    private val zipManager = ZipManager(context)

    private fun getExportsDir(): File {
        val dir = File(context.cacheDir, "exports")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    suspend fun generateAndroidStudioProjectZip(project: ProjectEntity): File = withContext(Dispatchers.IO) {
        val exportsDir = getExportsDir()
        val safeName = project.name.replace(Regex("[^a-zA-Z0-9_-]"), "_").lowercase()
        val zipFile = File(exportsDir, "${safeName}_android_project.zip")
        if (zipFile.exists()) zipFile.delete()

        val projectSourceDir = zipManager.getProjectDirectory(project.projectDir)
        val packagePath = project.packageName.replace('.', '/')

        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            // 1. Root settings.gradle.kts
            val settingsGradle = """
                pluginManagement {
                    repositories {
                        google()
                        mavenCentral()
                        gradlePluginPortal()
                    }
                }
                dependencyResolutionManagement {
                    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
                    repositories {
                        google()
                        mavenCentral()
                    }
                }
                rootProject.name = "${project.name}"
                include(":app")
            """.trimIndent()
            addZipEntry(zos, "settings.gradle.kts", settingsGradle.toByteArray())

            // 2. Root build.gradle.kts
            val rootBuildGradle = """
                plugins {
                    id("com.android.application") version "8.5.2" apply false
                    id("org.jetbrains.kotlin.android") version "2.0.0" apply false
                }
            """.trimIndent()
            addZipEntry(zos, "build.gradle.kts", rootBuildGradle.toByteArray())

            // 3. gradle.properties
            val gradleProps = """
                org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
                android.useAndroidX=true
                android.nonTransitiveRClass=true
            """.trimIndent()
            addZipEntry(zos, "gradle.properties", gradleProps.toByteArray())

            // 4. app/build.gradle.kts
            val appBuildGradle = """
                plugins {
                    id("com.android.application")
                    id("org.jetbrains.kotlin.android")
                }

                android {
                    namespace = "${project.packageName}"
                    compileSdk = 34

                    defaultConfig {
                        applicationId = "${project.packageName}"
                        minSdk = 24
                        targetSdk = 34
                        versionCode = ${project.versionCode}
                        versionName = "${project.versionName}"

                        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
                    }

                    buildTypes {
                        release {
                            isMinifyEnabled = false
                            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
                        }
                    }
                    compileOptions {
                        sourceCompatibility = JavaVersion.VERSION_1_8
                        targetCompatibility = JavaVersion.VERSION_1_8
                    }
                    kotlinOptions {
                        jvmTarget = "1.8"
                    }
                }

                dependencies {
                    implementation("androidx.core:core-ktx:1.13.1")
                    implementation("androidx.appcompat:appcompat:1.7.0")
                    implementation("com.google.android.material:material:1.12.0")
                    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
                    implementation("androidx.webkit:webkit:1.11.0")
                }
            """.trimIndent()
            addZipEntry(zos, "app/build.gradle.kts", appBuildGradle.toByteArray())

            // 5. AndroidManifest.xml
            val permissionsList = project.permissions.split(",").filter { it.isNotBlank() }
            val permXml = permissionsList.joinToString("\n    ") {
                "<uses-permission android:name=\"android.permission.$it\" />"
            }

            val orientationAttr = when (project.orientation) {
                "PORTRAIT" -> "android:screenOrientation=\"portrait\""
                "LANDSCAPE" -> "android:screenOrientation=\"landscape\""
                else -> "android:screenOrientation=\"sensor\""
            }

            val manifestXml = """
                <?xml version="1.0" encoding="utf-8"?>
                <manifest xmlns:android="http://schemas.android.com/apk/res/android"
                    xmlns:tools="http://schemas.android.com/tools">

                    $permXml

                    <application
                        android:allowBackup="true"
                        android:icon="@android:drawable/sym_def_app_icon"
                        android:label="@string/app_name"
                        android:roundIcon="@android:drawable/sym_def_app_icon"
                        android:supportsRtl="true"
                        android:theme="@style/Theme.${safeName.capitalize()}">

                        <activity
                            android:name=".MainActivity"
                            android:exported="true"
                            $orientationAttr
                            android:configChanges="orientation|screenSize|keyboardHidden"
                            android:theme="@style/Theme.${safeName.capitalize()}">
                            <intent-filter>
                                <action android:name="android.intent.action.MAIN" />
                                <category android:name="android.intent.category.LAUNCHER" />
                            </intent-filter>
                        </activity>
                    </application>
                </manifest>
            """.trimIndent()
            addZipEntry(zos, "app/src/main/AndroidManifest.xml", manifestXml.toByteArray())

            // 6. MainActivity.kt
            val mainActivityCode = generateMainActivityCode(project)
            addZipEntry(zos, "app/src/main/java/$packagePath/MainActivity.kt", mainActivityCode.toByteArray())

            // 7. res/values/strings.xml
            val stringsXml = """
                <resources>
                    <string name="app_name">${project.name}</string>
                </resources>
            """.trimIndent()
            addZipEntry(zos, "app/src/main/res/values/strings.xml", stringsXml.toByteArray())

            // 8. res/values/colors.xml
            val colorsXml = """
                <resources>
                    <color name="primary">${project.themeColorHex}</color>
                    <color name="splash_bg">${project.splashBgColorHex}</color>
                </resources>
            """.trimIndent()
            addZipEntry(zos, "app/src/main/res/values/colors.xml", colorsXml.toByteArray())

            // 9. res/values/themes.xml
            val themeXml = """
                <resources>
                    <style name="Theme.${safeName.capitalize()}" parent="Theme.MaterialComponents.DayNight.NoActionBar">
                        <item name="colorPrimary">@color/primary</item>
                        <item name="android:statusBarColor">@color/primary</item>
                        <item name="android:windowFullscreen">${project.isFullscreen}</item>
                    </style>
                </resources>
            """.trimIndent()
            addZipEntry(zos, "app/src/main/res/values/themes.xml", themeXml.toByteArray())

            // 10. Copy all web assets into app/src/main/assets/www/
            if (projectSourceDir.exists()) {
                val files = projectSourceDir.walkTopDown().filter { it.isFile }.toList()
                for (file in files) {
                    val relativePath = file.relativeTo(projectSourceDir).path.replace('\\', '/')
                    addZipFileEntry(zos, "app/src/main/assets/www/$relativePath", file)
                }
            }

            // 11. README
            val readme = """
                # ${project.name} - Standalone Android Project
                Generated by Web2APK

                ## How to build
                1. Open this unzipped folder in Android Studio.
                2. Wait for Gradle sync to complete.
                3. Connect an Android phone or launch an emulator.
                4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
                5. For Play Store publishing, configure your own private release signing key.

                Note: This ZIP contains the project-specific source and web assets. It is not itself an APK.
            """.trimIndent()
            addZipEntry(zos, "README.md", readme.toByteArray())
        }

        zipFile
    }

    suspend fun generateStandaloneApk(project: ProjectEntity): File = withContext(Dispatchers.IO) {
        throw IllegalStateException(
            "Direct APK compilation is not available in this app build. Export the Android Studio Project ZIP; " +
                "the bundled APK was a fixed sample and cannot be customized safely."
        )
    }

    private fun generateMainActivityCode(project: ProjectEntity): String {
        return """
            package ${project.packageName}

            import android.annotation.SuppressLint
            import android.graphics.Color
            import android.os.Bundle
            import android.view.View
            import android.webkit.WebChromeClient
            import android.webkit.WebSettings
            import android.webkit.WebView
            import android.webkit.WebViewClient
            import androidx.appcompat.app.AppCompatActivity
            import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

            class MainActivity : AppCompatActivity() {

                private lateinit var webView: WebView
                private var swipeRefreshLayout: SwipeRefreshLayout? = null

                @SuppressLint("SetJavaScriptEnabled")
                override fun onCreate(savedInstanceState: Bundle?) {
                    super.onCreate(savedInstanceState)

                    ${if (project.isFullscreen) "window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)" else ""}

                    webView = WebView(this)
                    val settings = webView.settings
                    settings.javaScriptEnabled = ${project.enableJavaScript}
                    settings.domStorageEnabled = ${project.enableDomStorage}
                    settings.databaseEnabled = true
                    settings.allowFileAccess = true
                    settings.allowContentAccess = true
                    settings.builtInZoomControls = false
                    settings.displayZoomControls = false
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true

                    ${if (project.customUserAgent.isNotBlank()) "settings.userAgentString = \"${project.customUserAgent}\"" else ""}
                    ${if (project.enableOfflineCache) "settings.cacheMode = WebSettings.LOAD_DEFAULT" else "settings.cacheMode = WebSettings.LOAD_NO_CACHE"}

                    webView.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            swipeRefreshLayout?.isRefreshing = false
                        }
                    }

                    webView.webChromeClient = WebChromeClient()

                    ${if (project.enablePullToRefresh) """
                        val refresh = SwipeRefreshLayout(this)
                        refresh.addView(webView)
                        refresh.setOnRefreshListener { webView.reload() }
                        swipeRefreshLayout = refresh
                        setContentView(refresh)
                    """ else """
                        setContentView(webView)
                    """}

                    // Load Web App Entry Point
                    ${if (project.sourceType == "URL" && !project.targetUrl.isNullOrBlank()) {
                        "webView.loadUrl(\"${project.targetUrl}\")"
                    } else {
                        "webView.loadUrl(\"file:///android_asset/www/${project.entryPoint}\")"
                    }}
                }

                override fun onBackPressed() {
                    if (webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        super.onBackPressed()
                    }
                }
            }
        """.trimIndent()
    }

    private fun addZipEntry(zos: ZipOutputStream, entryName: String, data: ByteArray) {
        val entry = ZipEntry(entryName)
        zos.putNextEntry(entry)
        zos.write(data)
        zos.closeEntry()
    }

    private fun addZipFileEntry(zos: ZipOutputStream, entryName: String, file: File) {
        val entry = ZipEntry(entryName)
        zos.putNextEntry(entry)
        FileInputStream(file).use { fis ->
            fis.copyTo(zos)
        }
        zos.closeEntry()
    }

    fun getShareIntent(file: File, mimeType: String = "application/zip"): Intent {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(intent, "Share " + file.name)
    }

    suspend fun copyFileToUri(sourceFile: File, targetUri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openOutputStream(targetUri)?.use { output ->
                FileInputStream(sourceFile).use { input ->
                    input.copyTo(output)
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
