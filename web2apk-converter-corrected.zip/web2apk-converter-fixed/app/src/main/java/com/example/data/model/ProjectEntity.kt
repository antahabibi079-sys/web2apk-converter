package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val packageName: String = "com.mycompany.webapp",
    val versionName: String = "1.0.0",
    val versionCode: Int = 1,
    val sourceType: String = "ZIP", // ZIP, HTML, TEMPLATE, URL
    val projectDir: String = "", // relative folder in context.filesDir
    val entryPoint: String = "index.html",
    val targetUrl: String? = null,
    val themeColorHex: String = "#0284C7",
    val orientation: String = "SENSOR", // SENSOR, PORTRAIT, LANDSCAPE
    val isFullscreen: Boolean = false,
    val enableJavaScript: Boolean = true,
    val enableDomStorage: Boolean = true,
    val enablePullToRefresh: Boolean = true,
    val enableOfflineCache: Boolean = true,
    val showSplash: Boolean = true,
    val splashDurationMs: Long = 1500L,
    val splashBgColorHex: String = "#0F172A",
    val customUserAgent: String = "",
    val permissions: String = "INTERNET,ACCESS_NETWORK_STATE",
    val iconType: String = "EMOJI", // EMOJI, PRESET
    val iconData: String = "🚀",
    val fileCount: Int = 1,
    val totalSizeBytes: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
