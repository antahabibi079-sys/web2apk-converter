package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.engine.ProjectGenerator
import com.example.data.engine.ZipManager
import com.example.data.model.ConsoleLog
import com.example.data.model.ConsoleLogLevel
import com.example.data.model.ProjectEntity
import com.example.data.model.TemplateItem
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

sealed class Screen {
    object Home : Screen()
    data class Config(val projectId: Long) : Screen()
    data class Emulator(val projectId: Long) : Screen()
    data class Editor(val projectId: Long) : Screen()
    data class BuildExport(val projectId: Long) : Screen()
}

data class UiState(
    val currentScreen: Screen = Screen.Home,
    val selectedProject: ProjectEntity? = null,
    val isProcessing: Boolean = false,
    val processingMessage: String = "",
    val projectFiles: List<File> = emptyList(),
    val activeFile: File? = null,
    val activeFileContent: String = "",
    val isBuilding: Boolean = false,
    val buildProgress: Float = 0f,
    val buildStepText: String = "",
    val exportedFile: File? = null,
    val exportedType: String = "", // "APK" or "ZIP"
    val buildError: String? = null,
    val buildLogs: List<String> = emptyList(),
    val consoleLogs: List<ConsoleLog> = emptyList(),
    val message: String? = null
)

class WebToApkViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val projectDao = db.projectDao()
    val zipManager by lazy { ZipManager(getApplication()) }
    val projectGenerator by lazy { ProjectGenerator(getApplication()) }

    val allProjects: StateFlow<List<ProjectEntity>> = projectDao.getAllProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    fun navigateTo(screen: Screen) {
        _uiState.value = _uiState.value.copy(currentScreen = screen)
    }

    fun clearMessage() {
        _uiState.value = _uiState.value.copy(message = null)
    }

    fun showMessage(msg: String) {
        _uiState.value = _uiState.value.copy(message = msg)
    }

    fun selectProject(project: ProjectEntity, targetScreen: Screen? = null) {
        _uiState.value = _uiState.value.copy(
            selectedProject = project,
            currentScreen = targetScreen ?: _uiState.value.currentScreen
        )
        loadProjectFiles(project)
    }

    private fun loadProjectFiles(project: ProjectEntity) {
        viewModelScope.launch {
            val files = zipManager.listProjectFiles(project.projectDir)
            val indexFile = files.firstOrNull { it.name.equals(project.entryPoint, ignoreCase = true) }
                ?: files.firstOrNull()
            val content = if (indexFile != null) zipManager.readFileContent(indexFile) else ""

            _uiState.value = _uiState.value.copy(
                projectFiles = files,
                activeFile = indexFile,
                activeFileContent = content
            )
        }
    }

    fun selectActiveFile(file: File) {
        viewModelScope.launch {
            val content = zipManager.readFileContent(file)
            _uiState.value = _uiState.value.copy(
                activeFile = file,
                activeFileContent = content
            )
        }
    }

    fun saveActiveFileContent(newContent: String) {
        val file = _uiState.value.activeFile ?: return
        viewModelScope.launch {
            val success = zipManager.writeFileContent(file, newContent)
            if (success) {
                _uiState.value = _uiState.value.copy(
                    activeFileContent = newContent,
                    message = "Saved ${file.name}"
                )
            } else {
                _uiState.value = _uiState.value.copy(message = "Failed to save ${file.name}")
            }
        }
    }

    fun importZipArchive(uri: Uri, originalName: String? = null) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isProcessing = true,
                processingMessage = "Extracting and analyzing ZIP package..."
            )

            val folderId = "proj_${System.currentTimeMillis()}"
            val res = zipManager.extractZipFromUri(uri, folderId)

            if (res.success) {
                val appName = originalName?.removeSuffix(".zip")?.replace(Regex("[_-]"), " ")
                    ?: "Converted Web App"
                val safePkg = "com.app." + appName.lowercase().replace(Regex("[^a-z0-9]"), "")

                val entity = ProjectEntity(
                    name = appName,
                    packageName = if (safePkg.length > 8) safePkg else "com.app.mywebapp",
                    sourceType = "ZIP",
                    projectDir = folderId,
                    entryPoint = res.entryPoint,
                    fileCount = res.fileCount,
                    totalSizeBytes = res.totalSizeBytes
                )

                val id = projectDao.insertProject(entity)
                val savedProject = entity.copy(id = id)

                selectProject(savedProject, Screen.Config(id))
                _uiState.value = _uiState.value.copy(
                    isProcessing = false,
                    message = "ZIP unpacked successfully: ${res.fileCount} files found"
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    isProcessing = false,
                    message = "Extraction error: ${res.error}"
                )
            }
        }
    }

    fun importHtmlFile(uri: Uri, originalName: String? = null) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isProcessing = true,
                processingMessage = "Importing HTML document..."
            )

            val folderId = "proj_${System.currentTimeMillis()}"
            val res = zipManager.saveSingleHtml(uri, folderId)

            if (res.success) {
                val appName = originalName?.removeSuffix(".html")?.removeSuffix(".htm")?.replace(Regex("[_-]"), " ")
                    ?: "HTML Web App"
                val safePkg = "com.app." + appName.lowercase().replace(Regex("[^a-z0-9]"), "")

                val entity = ProjectEntity(
                    name = appName,
                    packageName = if (safePkg.length > 8) safePkg else "com.app.htmlapp",
                    sourceType = "HTML",
                    projectDir = folderId,
                    entryPoint = "index.html",
                    fileCount = 1,
                    totalSizeBytes = res.totalSizeBytes
                )

                val id = projectDao.insertProject(entity)
                val savedProject = entity.copy(id = id)

                selectProject(savedProject, Screen.Config(id))
                _uiState.value = _uiState.value.copy(
                    isProcessing = false,
                    message = "HTML converted into project!"
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    isProcessing = false,
                    message = "Error: ${res.error}"
                )
            }
        }
    }

    fun createFromTemplate(template: TemplateItem) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isProcessing = true,
                processingMessage = "Creating project from ${template.name}..."
            )

            val folderId = "proj_${System.currentTimeMillis()}"
            val res = zipManager.createTemplateProject(
                folderName = folderId,
                htmlContent = template.htmlContent,
                cssContent = template.cssContent,
                jsContent = template.jsContent
            )

            if (res.success) {
                val safePkg = "com.app." + template.id.lowercase().replace(Regex("[^a-z0-9]"), "")
                val entity = ProjectEntity(
                    name = template.name,
                    packageName = safePkg,
                    sourceType = "TEMPLATE",
                    projectDir = folderId,
                    entryPoint = res.entryPoint,
                    themeColorHex = template.themeColorHex,
                    orientation = template.defaultOrientation,
                    isFullscreen = template.isFullscreen,
                    iconType = "EMOJI",
                    iconData = template.iconEmoji,
                    fileCount = res.fileCount,
                    totalSizeBytes = res.totalSizeBytes
                )

                val id = projectDao.insertProject(entity)
                val savedProject = entity.copy(id = id)

                selectProject(savedProject, Screen.Config(id))
                _uiState.value = _uiState.value.copy(
                    isProcessing = false,
                    message = "${template.name} ready to customize and export!"
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    isProcessing = false,
                    message = "Error: ${res.error}"
                )
            }
        }
    }

    fun createFromUrl(name: String, url: String) {
        viewModelScope.launch {
            val safeUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) "https://$url" else url
            val safePkg = "com.app." + name.lowercase().replace(Regex("[^a-z0-9]"), "")

            val entity = ProjectEntity(
                name = name,
                packageName = if (safePkg.length > 8) safePkg else "com.app.webapp",
                sourceType = "URL",
                targetUrl = safeUrl,
                iconType = "EMOJI",
                iconData = "🌐",
                fileCount = 0,
                totalSizeBytes = 0
            )

            val id = projectDao.insertProject(entity)
            val savedProject = entity.copy(id = id)

            selectProject(savedProject, Screen.Config(id))
            _uiState.value = _uiState.value.copy(
                message = "URL Web App project created!"
            )
        }
    }

    fun updateProject(project: ProjectEntity) {
        viewModelScope.launch {
            val updated = project.copy(updatedAt = System.currentTimeMillis())
            projectDao.updateProject(updated)
            _uiState.value = _uiState.value.copy(
                selectedProject = updated,
                message = "Settings updated"
            )
        }
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch {
            projectDao.deleteProject(project)
            if (_uiState.value.selectedProject?.id == project.id) {
                _uiState.value = _uiState.value.copy(
                    selectedProject = null,
                    currentScreen = Screen.Home
                )
            }
            _uiState.value = _uiState.value.copy(message = "Deleted ${project.name}")
        }
    }

    fun buildApk(project: ProjectEntity) {
        // A precompiled APK cannot be safely customized by copying it: its manifest,
        // package ID, signing block and embedded HTML are already fixed. Export the
        // real project sources instead of returning a misleading, unrelated APK.
        viewModelScope.launch {
            val logs = mutableListOf<String>()
            fun addLog(message: String) {
                val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
                logs.add("[$time] $message")
            }
            _uiState.value = _uiState.value.copy(
                isBuilding = true,
                buildProgress = 0.15f,
                buildStepText = "Preparing your Android project...",
                buildError = null,
                buildLogs = logs,
                exportedFile = null,
                exportedType = null,
                currentScreen = Screen.BuildExport(project.id)
            )
            try {
                addLog("Reading project ${project.name} and its web assets...")
                _uiState.value = _uiState.value.copy(buildProgress = 0.45f, buildStepText = "Packaging project-specific files", buildLogs = ArrayList(logs))
                val zip = projectGenerator.generateAndroidStudioProjectZip(project)
                addLog("Project source package created: ${zip.name}")
                addLog("No APK was fabricated. Build the APK from this project using Android Studio.")
                _uiState.value = _uiState.value.copy(
                    isBuilding = false,
                    buildProgress = 1f,
                    buildStepText = "Buildable Android project ready",
                    exportedFile = zip,
                    exportedType = "ZIP",
                    buildError = null,
                    buildLogs = ArrayList(logs),
                    message = "Project ZIP ready. APK compilation requires Android build tools."
                )
            } catch (e: Exception) {
                addLog("PROJECT EXPORT FAILED: ${e.localizedMessage}")
                _uiState.value = _uiState.value.copy(
                    isBuilding = false,
                    buildProgress = 0f,
                    buildStepText = "Project export failed",
                    exportedFile = null,
                    exportedType = null,
                    buildError = e.localizedMessage ?: "Unknown export error",
                    buildLogs = ArrayList(logs),
                    message = "Export failed: ${e.localizedMessage}"
                )
            }
        }
    }

    fun buildProjectZip(project: ProjectEntity) {
        viewModelScope.launch {
            val logs = mutableListOf<String>()
            fun addLog(msg: String) {
                logs.add("[${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}] $msg")
            }

            _uiState.value = _uiState.value.copy(
                isBuilding = true,
                buildProgress = 0.2f,
                buildStepText = "Configuring Gradle build scripts and Android Manifest...",
                buildError = null,
                buildLogs = logs,
                currentScreen = Screen.BuildExport(project.id)
            )
            addLog("Generating Android Studio project structure...")
            delay(300)

            try {
                _uiState.value = _uiState.value.copy(
                    buildProgress = 0.55f,
                    buildStepText = "Generating MainActivity.kt with custom WebView engine...",
                    buildLogs = ArrayList(logs)
                )
                addLog("Writing settings.gradle.kts, build.gradle.kts, and MainActivity.kt...")
                delay(300)

                _uiState.value = _uiState.value.copy(
                    buildProgress = 0.85f,
                    buildStepText = "Packaging Android Studio project ZIP...",
                    buildLogs = ArrayList(logs)
                )
                addLog("Archiving Android Studio project...")

                val zip = projectGenerator.generateAndroidStudioProjectZip(project)
                addLog("Project archive generated: ${zip.name} (${zip.length() / 1024} KB)")

                _uiState.value = _uiState.value.copy(
                    isBuilding = false,
                    buildProgress = 1.0f,
                    buildStepText = "Android Studio Project ready!",
                    exportedFile = zip,
                    exportedType = "ZIP",
                    buildError = null,
                    buildLogs = ArrayList(logs),
                    message = "Android Studio project ready!"
                )
            } catch (e: Exception) {
                addLog("ZIP BUILD FAILED: ${e.localizedMessage}")
                _uiState.value = _uiState.value.copy(
                    isBuilding = false,
                    buildProgress = 0f,
                    buildStepText = "Project generation failed",
                    exportedFile = null,
                    buildError = e.localizedMessage ?: "Unknown generation error",
                    buildLogs = ArrayList(logs),
                    message = "Generation failed: ${e.localizedMessage}"
                )
            }
        }
    }

    fun addConsoleLog(message: String, level: ConsoleLogLevel = ConsoleLogLevel.LOG, source: String = "", line: Int = 0) {
        val newLog = ConsoleLog(
            level = level,
            message = message,
            source = source,
            lineNumber = line
        )
        _uiState.value = _uiState.value.copy(
            consoleLogs = _uiState.value.consoleLogs + newLog
        )
    }

    fun clearConsoleLogs() {
        _uiState.value = _uiState.value.copy(consoleLogs = emptyList())
    }
}
