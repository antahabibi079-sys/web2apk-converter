package com.example.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.engine.ZipManager
import com.example.data.model.ConsoleLogLevel
import com.example.data.model.ProjectEntity
import com.example.ui.components.AppHeader
import com.example.ui.components.ConsoleBottomSheet
import com.example.ui.viewmodel.UiState
import kotlinx.coroutines.delay
import java.io.File

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun EmulatorScreen(
    project: ProjectEntity,
    uiState: UiState,
    onAddConsoleLog: (String, ConsoleLogLevel, String, Int) -> Unit,
    onClearConsoleLogs: () -> Unit,
    onOpenConfig: () -> Unit,
    onOpenEditor: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var webProgress by remember { mutableFloatStateOf(0f) }
    var isLoading by remember { mutableStateOf(true) }
    var showConsoleSheet by remember { mutableStateOf(false) }
    var isSplashVisible by remember { mutableStateOf(project.showSplash) }
    var deviceMode by remember { mutableStateOf("PHONE") } // "PHONE", "FULL"

    // Back handling inside WebView
    BackHandler {
        if (webViewInstance?.canGoBack() == true) {
            webViewInstance?.goBack()
        } else {
            onBack()
        }
    }

    // Splash Screen delay timer
    LaunchedEffect(project.id) {
        if (project.showSplash) {
            delay(project.splashDurationMs)
            isSplashVisible = false
        }
    }

    // Determine target URL
    val targetUrl = remember(project) {
        if (project.sourceType == "URL" && !project.targetUrl.isNullOrBlank()) {
            project.targetUrl
        } else {
            val zipManager = ZipManager(context)
            val projectDir = zipManager.getProjectDirectory(project.projectDir)
            val entryFile = File(projectDir, project.entryPoint)
            if (entryFile.exists()) {
                "file://${entryFile.absolutePath}"
            } else {
                val anyHtml = projectDir.walkTopDown().firstOrNull { it.extension.equals("html", true) }
                if (anyHtml != null) "file://${anyHtml.absolutePath}"
                else "about:blank"
            }
        }
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = project.name,
                subtitle = "Live Emulator • ${project.packageName}",
                onBack = onBack,
                actions = {
                    // Viewport toggle
                    IconButton(
                        onClick = { deviceMode = if (deviceMode == "PHONE") "FULL" else "PHONE" },
                        modifier = Modifier.testTag("toggle_viewport_btn")
                    ) {
                        Icon(
                            imageVector = if (deviceMode == "PHONE") Icons.Default.Laptop else Icons.Default.PhoneAndroid,
                            contentDescription = "Toggle viewport size"
                        )
                    }

                    // Code Editor shortcut
                    IconButton(
                        onClick = onOpenEditor,
                        modifier = Modifier.testTag("shortcut_editor_btn")
                    ) {
                        Icon(Icons.Default.Code, contentDescription = "Edit source code")
                    }

                    // DevTools Console with Badge
                    IconButton(
                        onClick = { showConsoleSheet = true },
                        modifier = Modifier.testTag("open_console_btn")
                    ) {
                        BadgedBox(
                            badge = {
                                if (uiState.consoleLogs.isNotEmpty()) {
                                    val errCount = uiState.consoleLogs.count { it.level == ConsoleLogLevel.ERROR }
                                    Badge(
                                        containerColor = if (errCount > 0) Color(0xFFEF4444) else Color(0xFF38BDF8)
                                    ) {
                                        Text("${uiState.consoleLogs.size}")
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Terminal, contentDescription = "Console logs")
                        }
                    }

                    IconButton(
                        onClick = onOpenConfig,
                        modifier = Modifier.testTag("shortcut_config_btn")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "APK Settings")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFF0B0F19)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Emulator Control Toolbar
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF111827),
                tonalElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { webViewInstance?.goBack() },
                            enabled = webViewInstance?.canGoBack() == true,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", modifier = Modifier.size(18.dp), tint = Color(0xFF94A3B8))
                        }

                        IconButton(
                            onClick = { webViewInstance?.goForward() },
                            enabled = webViewInstance?.canGoForward() == true,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Forward", modifier = Modifier.size(18.dp), tint = Color(0xFF94A3B8))
                        }

                        IconButton(
                            onClick = { webViewInstance?.reload() },
                            modifier = Modifier.size(36.dp).testTag("reload_webview_btn")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reload", modifier = Modifier.size(18.dp), tint = Color(0xFF38BDF8))
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF1E293B)
                    ) {
                        Text(
                            text = if (targetUrl.startsWith("file://")) "local://${project.entryPoint}" else targetUrl,
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            maxLines = 1,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (project.orientation == "LANDSCAPE") Color(0xFF16A34A).copy(0.2f) else Color(0xFF0284C7).copy(0.2f)
                    ) {
                        Text(
                            text = project.orientation,
                            color = if (project.orientation == "LANDSCAPE") Color(0xFF4ADE80) else Color(0xFF38BDF8),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Web Loading Progress Bar
            if (isLoading) {
                LinearProgressIndicator(
                    progress = { webProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp),
                    color = Color(0xFF38BDF8),
                    trackColor = Color(0xFF1E293B)
                )
            } else {
                Spacer(modifier = Modifier.height(3.dp))
            }

            // Device Frame Box
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(if (deviceMode == "PHONE") 12.dp else 0.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .then(
                            if (deviceMode == "PHONE") Modifier.widthIn(max = 420.dp).fillMaxSize()
                            else Modifier.fillMaxSize()
                        )
                        .border(
                            width = if (deviceMode == "PHONE") 4.dp else 0.dp,
                            color = Color(0xFF334155),
                            shape = if (deviceMode == "PHONE") RoundedCornerShape(28.dp) else RoundedCornerShape(0.dp)
                        )
                        .clip(if (deviceMode == "PHONE") RoundedCornerShape(28.dp) else RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.Black),
                    shape = if (deviceMode == "PHONE") RoundedCornerShape(28.dp) else RoundedCornerShape(0.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Phone Speaker/Notch (when in PHONE mode)
                        if (deviceMode == "PHONE") {
                            Box(
                                modifier = Modifier
                                    .padding(top = 8.dp)
                                    .size(width = 80.dp, height = 4.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF334155))
                                    .align(Alignment.TopCenter)
                            )
                        }

                        // Real Android WebView
                        AndroidView(
                            factory = { ctx ->
                                WebView(ctx).apply {
                                    layoutParams = ViewGroup.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT
                                    )
                                    settings.javaScriptEnabled = project.enableJavaScript
                                    settings.domStorageEnabled = project.enableDomStorage
                                    settings.databaseEnabled = true
                                    settings.allowFileAccess = true
                                    settings.allowContentAccess = true
                                    settings.useWideViewPort = true
                                    settings.loadWithOverviewMode = true
                                    settings.cacheMode = if (project.enableOfflineCache) {
                                        WebSettings.LOAD_DEFAULT
                                    } else {
                                        WebSettings.LOAD_NO_CACHE
                                    }

                                    if (project.customUserAgent.isNotBlank()) {
                                        settings.userAgentString = project.customUserAgent
                                    }

                                    webViewClient = object : WebViewClient() {
                                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                            super.onPageStarted(view, url, favicon)
                                            isLoading = true
                                        }

                                        override fun onPageFinished(view: WebView?, url: String?) {
                                            super.onPageFinished(view, url)
                                            isLoading = false
                                        }
                                    }

                                    webChromeClient = object : WebChromeClient() {
                                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                            super.onProgressChanged(view, newProgress)
                                            webProgress = newProgress / 100f
                                            if (newProgress >= 100) isLoading = false
                                        }

                                        override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                                            if (consoleMessage != null) {
                                                val lvl = when (consoleMessage.messageLevel()) {
                                                    ConsoleMessage.MessageLevel.ERROR -> ConsoleLogLevel.ERROR
                                                    ConsoleMessage.MessageLevel.WARNING -> ConsoleLogLevel.WARN
                                                    ConsoleMessage.MessageLevel.LOG -> ConsoleLogLevel.LOG
                                                    else -> ConsoleLogLevel.INFO
                                                }
                                                onAddConsoleLog(
                                                    consoleMessage.message(),
                                                    lvl,
                                                    consoleMessage.sourceId() ?: "",
                                                    consoleMessage.lineNumber()
                                                )
                                            }
                                            return true
                                        }
                                    }

                                    loadUrl(targetUrl)
                                    webViewInstance = this
                                }
                            },
                            update = { view ->
                                webViewInstance = view
                            },
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("emulator_webview")
                        )

                        // Simulated Splash Screen Overlay
                        androidx.compose.animation.AnimatedVisibility(
                            visible = isSplashVisible,
                            enter = fadeIn(),
                            exit = fadeOut(),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color(android.graphics.Color.parseColor(project.splashBgColorHex))),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(RoundedCornerShape(18.dp))
                                            .background(Color(android.graphics.Color.parseColor(project.themeColorHex))),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = project.iconData.ifBlank { "🚀" }, fontSize = 36.sp)
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))

                                    Text(
                                        text = project.name,
                                        color = Color.White,
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Spacer(modifier = Modifier.height(24.dp))

                                    CircularProgressIndicator(
                                        modifier = Modifier.size(24.dp),
                                        color = Color(android.graphics.Color.parseColor(project.themeColorHex)),
                                        strokeWidth = 2.5.dp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showConsoleSheet) {
        ConsoleBottomSheet(
            logs = uiState.consoleLogs,
            onClear = onClearConsoleLogs,
            onDismiss = { showConsoleSheet = false }
        )
    }
}
