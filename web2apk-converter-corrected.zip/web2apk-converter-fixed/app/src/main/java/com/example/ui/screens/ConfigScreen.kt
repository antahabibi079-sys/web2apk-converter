package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProjectEntity
import com.example.ui.components.AppHeader

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ConfigScreen(
    project: ProjectEntity,
    onSave: (ProjectEntity) -> Unit,
    onLaunchEmulator: () -> Unit,
    onOpenEditor: () -> Unit,
    onBuildApk: () -> Unit,
    onBack: () -> Unit
) {
    var name by remember(project) { mutableStateOf(project.name) }
    var packageName by remember(project) { mutableStateOf(project.packageName) }
    var versionName by remember(project) { mutableStateOf(project.versionName) }
    var versionCode by remember(project) { mutableIntStateOf(project.versionCode) }
    var iconEmoji by remember(project) { mutableStateOf(project.iconData) }

    var orientation by remember(project) { mutableStateOf(project.orientation) }
    var isFullscreen by remember(project) { mutableStateOf(project.isFullscreen) }
    var themeColorHex by remember(project) { mutableStateOf(project.themeColorHex) }

    var enableJavaScript by remember(project) { mutableStateOf(project.enableJavaScript) }
    var enableDomStorage by remember(project) { mutableStateOf(project.enableDomStorage) }
    var enablePullToRefresh by remember(project) { mutableStateOf(project.enablePullToRefresh) }
    var enableOfflineCache by remember(project) { mutableStateOf(project.enableOfflineCache) }
    var customUserAgent by remember(project) { mutableStateOf(project.customUserAgent) }

    var showSplash by remember(project) { mutableStateOf(project.showSplash) }
    var splashDurationMs by remember(project) { mutableFloatStateOf(project.splashDurationMs.toFloat()) }
    var splashBgColorHex by remember(project) { mutableStateOf(project.splashBgColorHex) }

    var permissions by remember(project) {
        mutableStateOf(project.permissions.split(",").filter { it.isNotBlank() }.toSet())
    }

    val availableEmojis = listOf("📱", "🚀", "🎮", "⚡", "🌐", "🧮", "💼", "📝", "🛒", "🔥", "✨", "🛠️")
    val availableColors = listOf("#0284C7", "#10B981", "#8B5CF6", "#F59E0B", "#F43F5E", "#0F172A")

    fun currentUpdatedProject(): ProjectEntity {
        return project.copy(
            name = name,
            packageName = packageName,
            versionName = versionName,
            versionCode = versionCode,
            iconData = iconEmoji,
            orientation = orientation,
            isFullscreen = isFullscreen,
            themeColorHex = themeColorHex,
            enableJavaScript = enableJavaScript,
            enableDomStorage = enableDomStorage,
            enablePullToRefresh = enablePullToRefresh,
            enableOfflineCache = enableOfflineCache,
            customUserAgent = customUserAgent,
            showSplash = showSplash,
            splashDurationMs = splashDurationMs.toLong(),
            splashBgColorHex = splashBgColorHex,
            permissions = permissions.joinToString(",")
        )
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Configure APK",
                subtitle = project.name,
                onBack = onBack,
                actions = {
                    IconButton(
                        onClick = { onSave(currentUpdatedProject()) },
                        modifier = Modifier.testTag("save_config_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = "Save settings")
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding(),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = {
                            onSave(currentUpdatedProject())
                            onOpenEditor()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("open_code_editor_btn")
                    ) {
                        Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Code")
                    }

                    FilledTonalButton(
                        onClick = {
                            onSave(currentUpdatedProject())
                            onLaunchEmulator()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("launch_emulator_btn")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Test App")
                    }

                    Button(
                        onClick = {
                            onSave(currentUpdatedProject())
                            onBuildApk()
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .weight(1.3f)
                            .testTag("build_apk_btn")
                    ) {
                        Icon(Icons.Default.RocketLaunch, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Build APK")
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 1. App Identity Card
            ConfigSectionCard(title = "App Identity & Launcher") {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("App Name (Launcher Label)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_app_name")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = packageName,
                    onValueChange = { packageName = it },
                    label = { Text("Package Name (Application ID)") },
                    placeholder = { Text("com.company.app") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_package_name")
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = versionName,
                        onValueChange = { versionName = it },
                        label = { Text("Version Name") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = versionCode.toString(),
                        onValueChange = { versionCode = it.toIntOrNull() ?: 1 },
                        label = { Text("Version Code") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "App Icon Avatar",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    availableEmojis.forEach { emoji ->
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (iconEmoji == emoji) MaterialTheme.colorScheme.primaryContainer
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { iconEmoji = emoji },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = emoji, fontSize = 20.sp)
                        }
                    }
                }
            }

            // 2. Display & Orientation
            ConfigSectionCard(title = "Display & Orientation") {
                Text(
                    text = "Screen Orientation",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = orientation == "PORTRAIT",
                        onClick = { orientation = "PORTRAIT" },
                        label = { Text("Portrait Only") }
                    )
                    FilterChip(
                        selected = orientation == "LANDSCAPE",
                        onClick = { orientation = "LANDSCAPE" },
                        label = { Text("Landscape (Games)") }
                    )
                    FilterChip(
                        selected = orientation == "SENSOR",
                        onClick = { orientation = "SENSOR" },
                        label = { Text("Auto-Rotate") }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Fullscreen Immersive Mode", fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "Hides Android status and navigation bars for games & full-bleed apps",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = isFullscreen,
                        onCheckedChange = { isFullscreen = it },
                        modifier = Modifier.testTag("fullscreen_switch")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Theme Brand Color",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    availableColors.forEach { hex ->
                        val color = Color(android.graphics.Color.parseColor(hex))
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(color)
                                .clickable { themeColorHex = hex },
                            contentAlignment = Alignment.Center
                        ) {
                            if (themeColorHex.equals(hex, ignoreCase = true)) {
                                Box(
                                    modifier = Modifier
                                        .size(14.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                )
                            }
                        }
                    }
                }
            }

            // 3. WebView Engine Settings
            ConfigSectionCard(title = "WebView Engine & Behavior") {
                ToggleOptionRow(
                    title = "Enable JavaScript",
                    subtitle = "Required for dynamic web scripts, games, and frameworks",
                    checked = enableJavaScript,
                    onCheckedChange = { enableJavaScript = it }
                )

                ToggleOptionRow(
                    title = "DOM Storage (localStorage)",
                    subtitle = "Allows web apps to store state, high scores, and user preferences offline",
                    checked = enableDomStorage,
                    onCheckedChange = { enableDomStorage = it }
                )

                ToggleOptionRow(
                    title = "Pull-to-Refresh Gesture",
                    subtitle = "Swipe down from top to reload the web page",
                    checked = enablePullToRefresh,
                    onCheckedChange = { enablePullToRefresh = it }
                )

                ToggleOptionRow(
                    title = "Offline Cache First",
                    subtitle = "Cache assets locally for zero-latency loading even with no signal",
                    checked = enableOfflineCache,
                    onCheckedChange = { enableOfflineCache = it }
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = customUserAgent,
                    onValueChange = { customUserAgent = it },
                    label = { Text("Custom User-Agent (Optional)") },
                    placeholder = { Text("Mozilla/5.0 (Linux; Android...)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // 4. Splash Screen
            ConfigSectionCard(title = "Splash Screen") {
                ToggleOptionRow(
                    title = "Show Animated Splash Screen",
                    subtitle = "Displays branded loading screen while web assets initialize",
                    checked = showSplash,
                    onCheckedChange = { showSplash = it }
                )

                if (showSplash) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Display Duration: ${(splashDurationMs / 1000f).let { String.format("%.1f s", it) }}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Slider(
                        value = splashDurationMs,
                        onValueChange = { splashDurationMs = it },
                        valueRange = 500f..4000f,
                        steps = 7,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // 5. Android Manifest Permissions
            ConfigSectionCard(title = "Android Permissions") {
                Text(
                    text = "Select hardware and system APIs to declare in AndroidManifest.xml:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                val availablePerms = listOf(
                    "INTERNET" to "Internet Access",
                    "ACCESS_NETWORK_STATE" to "Network Connectivity State",
                    "CAMERA" to "Camera (WebRTC / Photo upload)",
                    "RECORD_AUDIO" to "Microphone (Web Audio)",
                    "ACCESS_FINE_LOCATION" to "Geolocation API",
                    "VIBRATE" to "Haptic Feedback (navigator.vibrate)"
                )

                availablePerms.forEach { (permKey, permLabel) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                permissions = if (permissions.contains(permKey)) {
                                    permissions - permKey
                                } else {
                                    permissions + permKey
                                }
                            }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = permissions.contains(permKey),
                            onCheckedChange = { checked ->
                                permissions = if (checked) permissions + permKey else permissions - permKey
                            }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = permLabel, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            Text(text = "android.permission.$permKey", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ConfigSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
fun ToggleOptionRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontWeight = FontWeight.SemiBold)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
