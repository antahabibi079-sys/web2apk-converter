package com.example.data.engine

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

data class ExtractionResult(
    val success: Boolean,
    val entryPoint: String = "index.html",
    val fileCount: Int = 0,
    val totalSizeBytes: Long = 0L,
    val error: String? = null
)

class ZipManager(private val context: Context) {

    fun getProjectDirectory(folderName: String): File {
        val dir = File(context.filesDir, "projects/$folderName")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    suspend fun extractZipFromUri(uri: Uri, folderName: String): ExtractionResult = withContext(Dispatchers.IO) {
        val targetDir = getProjectDirectory(folderName)
        // Clean target directory first
        targetDir.deleteRecursively()
        targetDir.mkdirs()

        var fileCount = 0
        var totalBytes = 0L
        var foundIndexHtml: String? = null

        try {
            val inputStream: InputStream = context.contentResolver.openInputStream(uri)
                ?: return@withContext ExtractionResult(false, error = "Cannot open selected file stream")

            ZipInputStream(inputStream).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    val entryName = entry.name

                    // Avoid __MACOSX and hidden files
                    if (!entryName.startsWith("__MACOSX") && !entryName.contains("/.")) {
                        val newFile = File(targetDir, entryName)

                        // Path traversal check (Zip Slip vulnerability guard)
                        val canonicalDest = targetDir.canonicalPath
                        val canonicalEntry = newFile.canonicalPath
                        if (!canonicalEntry.startsWith(canonicalDest)) {
                            throw SecurityException("Zip entry is outside target dir: $entryName")
                        }

                        if (entry.isDirectory) {
                            newFile.mkdirs()
                        } else {
                            newFile.parentFile?.mkdirs()
                            FileOutputStream(newFile).use { fos ->
                                zis.copyTo(fos)
                            }
                            fileCount++
                            val size = newFile.length()
                            totalBytes += size

                            val simpleName = newFile.name.lowercase()
                            if (simpleName == "index.html" || simpleName == "index.htm") {
                                // Relative path from targetDir
                                val relPath = newFile.relativeTo(targetDir).path
                                if (foundIndexHtml == null || !relPath.contains(File.separator)) {
                                    foundIndexHtml = relPath
                                }
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            // If no index.html was directly found, check if there is an html file or look in subdirectories
            if (foundIndexHtml == null) {
                val allFiles = targetDir.walkTopDown().filter { it.isFile }.toList()
                val htmlFile = allFiles.firstOrNull { it.extension.equals("html", ignoreCase = true) || it.extension.equals("htm", ignoreCase = true) }
                if (htmlFile != null) {
                    foundIndexHtml = htmlFile.relativeTo(targetDir).path
                } else if (allFiles.isNotEmpty()) {
                    // Default to first file
                    foundIndexHtml = allFiles.first().relativeTo(targetDir).path
                } else {
                    foundIndexHtml = "index.html"
                }
            }

            ExtractionResult(
                success = true,
                entryPoint = foundIndexHtml ?: "index.html",
                fileCount = fileCount,
                totalSizeBytes = totalBytes
            )
        } catch (e: Exception) {
            ExtractionResult(
                success = false,
                error = e.localizedMessage ?: "Failed to extract ZIP archive"
            )
        }
    }

    suspend fun saveSingleHtml(uri: Uri, folderName: String): ExtractionResult = withContext(Dispatchers.IO) {
        val targetDir = getProjectDirectory(folderName)
        targetDir.deleteRecursively()
        targetDir.mkdirs()

        try {
            val destFile = File(targetDir, "index.html")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext ExtractionResult(false, error = "Failed to open HTML file")

            ExtractionResult(
                success = true,
                entryPoint = "index.html",
                fileCount = 1,
                totalSizeBytes = destFile.length()
            )
        } catch (e: Exception) {
            ExtractionResult(false, error = e.localizedMessage ?: "Failed to save HTML file")
        }
    }

    suspend fun createTemplateProject(folderName: String, htmlContent: String, cssContent: String = "", jsContent: String = ""): ExtractionResult = withContext(Dispatchers.IO) {
        val targetDir = getProjectDirectory(folderName)
        targetDir.deleteRecursively()
        targetDir.mkdirs()

        try {
            val indexFile = File(targetDir, "index.html")
            indexFile.writeText(htmlContent)

            var count = 1
            var totalBytes = indexFile.length()

            if (cssContent.isNotBlank()) {
                val cssFile = File(targetDir, "style.css")
                cssFile.writeText(cssContent)
                count++
                totalBytes += cssFile.length()
            }

            if (jsContent.isNotBlank()) {
                val jsFile = File(targetDir, "app.js")
                jsFile.writeText(jsContent)
                count++
                totalBytes += jsFile.length()
            }

            ExtractionResult(
                success = true,
                entryPoint = "index.html",
                fileCount = count,
                totalSizeBytes = totalBytes
            )
        } catch (e: Exception) {
            ExtractionResult(false, error = e.localizedMessage ?: "Failed to initialize template")
        }
    }

    suspend fun listProjectFiles(folderName: String): List<File> = withContext(Dispatchers.IO) {
        val targetDir = getProjectDirectory(folderName)
        if (!targetDir.exists()) return@withContext emptyList()
        targetDir.walkTopDown().filter { it.isFile }.toList()
    }

    suspend fun readFileContent(file: File): String = withContext(Dispatchers.IO) {
        try {
            file.readText()
        } catch (e: Exception) {
            "/* Binary or unreadable file: ${e.localizedMessage} */"
        }
    }

    suspend fun writeFileContent(file: File, content: String): Boolean = withContext(Dispatchers.IO) {
        try {
            file.writeText(content)
            true
        } catch (e: Exception) {
            false
        }
    }
}
