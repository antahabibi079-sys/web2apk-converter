# Web2APK Converter

Android app source project for importing HTML/CSS/JavaScript websites and generating a project-specific Android Studio project ZIP.

## Important

This application does not compile APK files on the Android phone. The previous bundled APK was a fixed sample (including a game) and could not be customized safely. That sample has been removed. The “Prepare Android Project” action now exports the actual selected project's source and web assets instead of returning an unrelated APK.

## Build this app

1. Open this folder in Android Studio on a computer.
2. Install the Android SDK for compile SDK 36 and allow Gradle sync.
3. Build and run the `app` module.
4. For a release build, configure your own private signing key in Android Studio. No signing key or API secret is included.

## Use the converter

1. Import a ZIP containing your website files, or import an HTML file.
2. Configure the app name, package ID, entry point, permissions and WebView options.
3. Choose **Prepare Android Project** or **Studio Project** to export a project ZIP.
4. Unzip that project on a computer, open it in Android Studio, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Security notes

- Do not put API keys or private credentials in HTML/JavaScript shipped to users.
- HTTPS is required by default; cleartext traffic is disabled in the converter app.
- Configure and protect your own release signing key. Never share it in a ZIP.
